package com.cg.parallelproject.dao;

import java.util.List;

import com.cg.parallelproject.dto.Customer;
import com.cg.parallelproject.dto.Transaction;

public interface WalletRepo {
	public boolean save(Customer customer);
	public Customer findOne(String mobileNo);
	public void addTransaction(Transaction t);
	public boolean createNewDetails(Customer pr);
	public List<Transaction> getAllTransaction(String mobile);
}
